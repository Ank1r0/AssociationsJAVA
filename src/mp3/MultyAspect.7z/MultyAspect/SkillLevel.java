package mp3.MultyAspect;

public enum SkillLevel {
    BEGINNER,
    INTERMEDIATE,
    PROFESSIONAL

}
